# Getting Started with Web3 Connect Wallet

Built with Create React App + Typescript + Web3 + Chakra-UI

## Instruction

```
git clone https://github.com/RikaiSoft/test-project.git
cd test-project
npm install
npm run start
```
Open [http://localhost:3005](http://localhost:3005) to view it in the browser.
